migrate((db) => {
  const collection = new Collection({
    "id": "c0du9n2psua9zqq",
    "created": "2023-04-04 04:39:45.852Z",
    "updated": "2023-04-04 04:39:45.852Z",
    "name": "brief",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "tm8qrrpe",
        "name": "brief",
        "type": "editor",
        "required": false,
        "unique": false,
        "options": {}
      },
      {
        "system": false,
        "id": "oguanpjk",
        "name": "version",
        "type": "number",
        "required": false,
        "unique": false,
        "options": {
          "min": 1,
          "max": 50000
        }
      },
      {
        "system": false,
        "id": "q0lhjtre",
        "name": "note",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "jag378xa",
        "name": "idclub",
        "type": "relation",
        "required": false,
        "unique": false,
        "options": {
          "collectionId": "tvi7fuufximvbbo",
          "cascadeDelete": true,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": [
            "id"
          ]
        }
      }
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq");

  return dao.deleteCollection(collection);
})

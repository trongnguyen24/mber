migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  collection.listRule = ""
  collection.viewRule = ""

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  collection.listRule = null
  collection.viewRule = null

  return dao.saveCollection(collection)
})

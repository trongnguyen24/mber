migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "jag378xa",
    "name": "club",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "tvi7fuufximvbbo",
      "cascadeDelete": true,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": [
        "id"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "jag378xa",
    "name": "idclub",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "collectionId": "tvi7fuufximvbbo",
      "cascadeDelete": true,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": [
        "id"
      ]
    }
  }))

  return dao.saveCollection(collection)
})

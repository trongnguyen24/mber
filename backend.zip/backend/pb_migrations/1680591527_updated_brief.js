migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "wdyl5tav",
    "name": "club",
    "type": "text",
    "required": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("c0du9n2psua9zqq")

  // remove
  collection.schema.removeField("wdyl5tav")

  return dao.saveCollection(collection)
})
